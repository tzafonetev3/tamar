for a in 32 128 167 192; do
 convert icon.png -resize $ax$a favicon-$a.png
done